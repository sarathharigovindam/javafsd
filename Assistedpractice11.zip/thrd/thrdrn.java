package thrd;

public class thrdrn extends Thread {
	
	 	public void run()
	 	{
	  		System.out.println("concurrent thread started running..");
	}
	 	public static void main( String args[] )
	 	{
	  		thrdrn mt = new  thrdrn();
	  		mt.start();
	 	}
	}



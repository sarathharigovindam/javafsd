package thrd;

 
	 class runablethread implements Runnable{
		 
	    public static int myCount = 0;
	    public runablethread(){
	         
	    }
	     public void run() {
	        while(runablethread.myCount <= 10){
	            try{
	                System.out.println("Expl Thread: "+(++runablethread.myCount));
	                Thread.sleep(100);
	            } catch (InterruptedException iex) {
	                System.out.println("Exception in thread: "+iex.getMessage());
	            }
	        }
	    } 
	    public static void main(String a[]){
	        System.out.println("Starting Main Thread...");
	        runablethread mrt = new runablethread();
	        Thread t = new Thread(mrt);
	        t.start();
	        while(runablethread.myCount <= 10){
	            try{
	                System.out.println("Main Thread: "+(++runablethread.myCount));
	                Thread.sleep(100);
	            } catch (InterruptedException iex){
	                System.out.println("Exception in main thread: "+iex.getMessage());
	            }
	        }
	        System.out.println("End of Main Thread...");
	    }
	}



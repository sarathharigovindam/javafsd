package acccesmodifiers;


class pr {
	private void display() 
    { 
        System.out.println("You are using private access specifier"); 
    } 
} 

public class priv {

	public static void main(String[] args) {
		
		System.out.println("Private Access Specifier");
		pr  obj = new pr(); 
        //trying to access private method of another class 
        //obj.display();

	}
}
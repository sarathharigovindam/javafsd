package acccesmodifiers;

class Abc {
	  void display() 
	     { 
	         System.out.println("You are using defalut access specifier"); 
	     } 
	} 

	public class def {

		public static void main(String[] args) {
			//default
			System.out.println("Dafault Access Specifier");
			Abc obj = new Abc(); 		  
	        obj.display(); 

		}
	}




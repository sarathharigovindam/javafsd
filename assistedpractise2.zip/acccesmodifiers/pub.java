package acccesmodifiers;

class xyz {
	
	    // public variable
	    public int count;

	    // public method
	    public void display() {
	        System.out.println("pub class.");
	        System.out.println("public class " + count );
	    }
	}

	// Main.java
	public class pub {
	    public static void main( String[] args ) {
	        // accessing the public class
	        xyz a = new xyz();

	        // accessing the public variable
	        a.count = 1;
	        // accessing the public method
	        a.display();
	    }
	}



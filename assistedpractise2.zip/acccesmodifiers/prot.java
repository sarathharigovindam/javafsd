package acccesmodifiers;

	class dog {
	    // protected method
	    protected void display() {
	        System.out.println("protected class");
	    }
	}

	class prot extends dog {
	    public static void main(String[] args) {

	        // create an object of Dog class
	        prot a= new prot();
	         // access protected method
	        a.display();
	    }
	}



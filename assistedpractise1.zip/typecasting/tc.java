package typecasting;

public class tc {

		public static void main(String[] args){
			
			
			System.out.println("Implicit Type Casting");
			char c1='A';
			System.out.println("Value of c1: "+c1);
			
			int c2=c1;
			System.out.println("Value of c2: "+c2);
			
			float c3=c1;
			System.out.println("Value of c3: "+c3);
			
			long c4=c1;
			System.out.println("Value of c4: "+c4);
			
			double c5=c1;
			System.out.println("Value of c5: "+c5);
			
					
			System.out.println("\n");
			
			System.out.println("Explicit Type Casting");
			
			
			double a=10.5;
			int b=(int)a;
			System.out.println("Value of a: "+a);
			System.out.println("Value of b: "+b);
			
		}
	}




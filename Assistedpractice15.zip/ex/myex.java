package ex;


	class Main extends Exception 
	{ 
	    
		Main(String s) 
	    { 
	        super(s); 
	    } 
	} 
	class myex 
	{ 
	    public static void main(String args[]) 
	    { 
	        try
	        { 
	            throw new Main("temp"); 
	        } 
	        catch (Main ex) 
	        { 
	            System.out.println("Caught"); 
	            System.out.println(ex.getMessage()); 
	        } 
	    } 

}

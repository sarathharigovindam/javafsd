package reg;
import java.util.regex.*;

class reexp {
	

	

	public static void main(String[] args) {

		String pattern = "[a-z]+";
		String check = "Sarath chelsea";
		Pattern p = Pattern.compile(pattern);
		Matcher c = p.matcher(check);
		
		while (c.find())
	      	System.out.println( check.substring( c.start()-1, c.end() ) );
		}
	}



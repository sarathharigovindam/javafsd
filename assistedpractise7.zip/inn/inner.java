package inn;

 class inner {
	

		 private String msg="hi"; 
		 
		 class Innerclss{  
		  void hello(){System.out.println(msg+", how are u?");}  
		 }  


		public static void main(String[] args) {

			inner obj=new inner();
			inner.Innerclss in=obj.new Innerclss();  
			in.hello();  
		}
	}


	
		


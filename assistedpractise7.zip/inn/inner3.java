package inn;

abstract class xyz {
	
		   public abstract void display();
		}


		 class inner3 {

		public static void main(String[] args) {
		xyz i = new xyz() {

		         public void display() {
		            System.out.println("Anonymous Inner Class");
		         }
		      };
		      i.display();
		   }
		}




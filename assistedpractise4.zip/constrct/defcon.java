package constrct;

 class abc {
	
		int id;
		String name;

	void display() {
		System.out.println(id+" "+name);
		}
	}

	 public class defcon {

	public static void main(String[] args) {

		abc emp1=new abc();
		abc emp2=new abc();

		emp1.display();
		emp2.display();
		}
	}



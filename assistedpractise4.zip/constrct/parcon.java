package constrct;

class abcd {
	
		int id;
		String name;

		abcd(int i,String n)
		{
		id=i;
		name=n;
		}

		void display() {
		System.out.println(id+" "+name);
		}
	}

	public class parcon {
	public static void main(String[] args) {

		abcd std1=new abcd(2,"Alex");
		abcd std2=new abcd(10,"Annie");
		std1.display();
		std2.display();
			}
	}


